"""MemoryForge: auditable local text snapshots and full-text search."""

__version__ = "0.3.0"
