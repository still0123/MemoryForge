# MemoryForge v0.3.0 Evidence Claims

本页只列可由仓库内 Evidence 直接核验的主张。局部结果不得外推为任意仓库、任意语言或生产 SLA。

## 发布门禁

| 主张 | Evidence | 边界 |
| --- | --- | --- |
| v0.2.1 的完整测试、Ruff、Mypy、四矩阵 CI 通过 | 历史 GitHub Actions `31074527750` | 仅证明已发布的 v0.2.1 Commit |
| 后续变更使用本地完整门禁 | [`scripts/check_local.sh`](../scripts/check_local.sh) 与本地 SHA256 Evidence | GitHub Actions 已关闭；不得宣称远端 CI |
| v0.3.0 release-candidate 使用双隔离构建、Workspace drill 和严格 Registry | [`V030_RELEASE_CANDIDATE_SPEC.md`](V030_RELEASE_CANDIDATE_SPEC.md) | 原生 Windows confirmation 与 holdout 通过前不得宣称已发布 |
| v0.3.0 RC 在 macOS 574 passed，Linux 571 passed / 3 skipped，coverage 88%，Wheel/sdist 跨平台 SHA256 一致 | [`release_candidate_candidate_1_local_gates.json`](../demo/results/release_candidate_candidate_1_local_gates.json) | 固定 Commit `3980b47`；Candidate 1 已 superseded，不等于原生 Windows confirmation |
| Candidate 2 development 6/6，真实核验 Wheel/sdist metadata、bytes、Commit 和 sdist clean-room | [`release_candidate_development_candidate_2.json`](../demo/results/release_candidate_development_candidate_2.json) | macOS/Linux 最终门禁待重跑；confirmation 与 holdout 未运行 |
| Candidate 2 首次 sdist preflight 因 macOS 路径 alias 失败且未生成输出目录 | [`release_candidate_sdist_probe_regression_rejected.json`](../demo/results/release_candidate_sdist_probe_regression_rejected.json) | 保留失败；修复使用 canonical path，未放宽 ownership gate |
| 开发与构建依赖可冻结重放 | [`constraints/dev.txt`](../constraints/dev.txt)，SHA256 `48debebcfd2da302201688e0582c676cb571d66e96cd7a2a2e0654f49a544571` | 仅覆盖声明的平台与 Python 版本 |
| Wheel 和 sdist 可独立安装 | 本地门禁与 [`run_release_check.py`](../demo/run_release_check.py) | 需要在精确 Commit 上重跑 |
| Release 产物有 SHA256 | 本地 `SHA256SUMS` 与手动回下载校验 | 不再生成 hosted attestation |

## 代码 Wiki

| 主张 | Evidence | 边界 |
| --- | --- | --- |
| Click/Cobra/Zod 共索引 2,445 Symbols、3,718 Relations | [`external_code_wiki_v021.json`](../demo/results/external_code_wiki_v021.json) | 固定 87 个 Source |
| learn-claude-code 索引 72 Symbols、111 Relations，冻结 20/15/5 标签均为 100% | [`external_code_wiki_learn_claude_code_v031.json`](../demo/results/external_code_wiki_learn_claude_code_v031.json) | 固定 5 个 canonical lesson Source；非穷举正样本 |
| learn-claude-code QA development Answer 为 60%、Citation 为 88.9%、Abstention 为 0% | [`learn_claude_code_qa_dev_v031.json`](../demo/results/learn_claude_code_qa_dev_v031.json) | 未过门禁，confirmation 未运行 |
| support-score development Answer/Selective Accuracy 为 100%，Coverage 为 90%，Risk 为 0% | [`support_score_development_candidate_14.json`](../demo/results/support_score_development_candidate_14.json) | 固定 10 题 development；confirmation 未运行 |
| multi-source development Selection/Source/Term Coverage 为 100%，重复来源率为 0% | [`multi_source_coverage_development_candidate_1.json`](../demo/results/multi_source_coverage_development_candidate_1.json) | 固定 6 个确定性案例；confirmation 未运行 |
| 60 Symbol、45 Relation、15 Module 正样本全部命中 | 同上，SHA256 `9073b96cad920df5bddcd46eadbbe507b0b673e8d714a0619ad0913fb6f6c496` | 非穷举正样本；不等于全仓 precision/recall |
| Zod 64 条 Architecture edge 的 Mermaid/Citation 为 100% | 同上 | Click/Cobra 无跨模块边，相关指标 N/A |
| 缓存决策为 `NO_CHANGE` | [`external_code_wiki_profile_v021.json`](../demo/results/external_code_wiki_profile_v021.json) | macOS 单机、每仓 3 次中位数 |
| Cobra 单文件变化页面比例为 50% | 同上 | 真实负结果；当前仅 2 个 Module |

## 文档 Wiki

| 主张 | Evidence | 边界 |
| --- | --- | --- |
| 原 30 题严格 Answer 为 96.7%，Citation 为 100%，Source recall@3 为 96.2% | [`agent_skill_eval_public.json`](../demo/results/agent_skill_eval_public.json) | Answer 必须同时命中冻结来源；单一公开仓库固定题集 |
| Click development/holdout Answer accuracy 为 10%/0% | [`click_docs_dev_v021.json`](../demo/results/click_docs_dev_v021.json)、[`click_docs_holdout_v021.json`](../demo/results/click_docs_holdout_v021.json) | 外部迁移负结果 |
| Click 两套 split 的 Citation grounding 为 100% | 同上 | 只证明引用可回读，不证明答案正确 |
| Click Source recall@3 为 0% | 同上 | holdout 已揭盲；禁止据此继续调参 |

## 展示与跨平台

| 主张 | Evidence | 边界 |
| --- | --- | --- |
| Static Showcase development 4/4，本地详情泄漏与 Workspace 变更均为 0 | [`static_showcase_development_candidate_5.json`](../demo/results/static_showcase_development_candidate_5.json) | confirmation 未运行 |
| macOS 本地门禁 559 passed，Linux 本地门禁 556 passed / 3 skipped，覆盖率 88% | [`CROSS_PLATFORM_DELIVERY_SPEC.md`](CROSS_PLATFORM_DELIVERY_SPEC.md) | 不等于原生 Windows confirmation |
| Candidate 1-8 的失败或 superseded 结果仍保留 | [`registry.json`](../demo/evaluation/registry.json) | 不把历史 gate 重新标为最终成功 |

## 面试表述

可以说“系统具备可审核、可回溯、可复现的编译与发布链路”。不能说“通用文档问答已解决”、
“任意仓库 precision/recall 为 100%”或“达到生产 SLA”。
